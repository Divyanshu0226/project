<?php
include 'connection.php';
$sql="update visitor_counter set visitor_counter=visitor_counter+1";
$stmt=$con->prepare($sql);
$stmt->execute();
$sql="select visitor_counter from visitor_counter";
$stmt=$con->prepare($sql);
$stmt->execute();
$arr=$stmt->fetchAll(PDO::FETCH_ASSOC);
$counter=$arr[0]['visitor_counter'];
$count=strlen($counter);
?>
<style>
	#visitor_counter li{list-style: none;

		float: left;
		background-color: #2DA8F8;
		padding: 1%;
		margin-left: 1%;
		color: #fff;
		font-size: 20px;
	}

</style>

<div>
	<ul id="visitor_counter">
		<?php for($i=0;$i<$count;$i++){?>
			<li><?php echo $counter[$i]?></li>
		<?php }?>
		
	</ul>
</div>