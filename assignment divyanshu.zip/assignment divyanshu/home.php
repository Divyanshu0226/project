<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Flexbox Tutorial</title>
    <?php include('header.php') ?>
    <br><br><br><br><br>
    <style>

div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
  box-sizing: border-box;
  padding: ;
  justify-content: space-around;
  overflow:hidden;

}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 200px;
  height: 200px;
  display: flex;

}

div.desc {
  padding: 15px;
  text-align: center;
  display: flex;
  box-sizing: border-box;
  padding: 15px;
  justify-content: space-around;


}

    </style>
</head>
<body>
    

<?php
include 'connection.php';

//fetching data into the category table//
$sql = "SELECT name, animal, image, description, life FROM category";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {



    ?>
<div class="gallery">
  
      <?php echo "<img src='  ".$row['image']. " 'width='50px''  '>"; ?>

  <div class="desc"><?php     
  echo  $row['name'] . "<br>" ;
  echo  $row['animal'] . "<br>";
  echo  $row['description'] . "<br>";
  echo  $row['life'];

  ?></div>
</div>


  
  <?php
  }
} else {
  echo "0 results";
}
$conn->close();
?>


</table>

  

</body>
</html>
